package com.jarvis.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int SPEECH_REQUEST = 71;
    private final int bg = Color.rgb(5,9,13), cyan = Color.rgb(0,229,255), white = Color.WHITE;
    private LinearLayout root, messages;
    private ScrollView scroll;
    private EditText input, keyInput;
    private TextView status;
    private SharedPreferences prefs;
    private TextToSpeech tts;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final JSONArray history = new JSONArray();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE);
        tts = new TextToSpeech(this, result -> { if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("tr", "TR")); });
        showChat();
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setPadding(dp(8),dp(7),dp(8),dp(7)); return t;
    }
    private Button button(String s) { Button b = new Button(this); b.setText(s); b.setTextColor(white); b.setAllCaps(false); return b; }
    private void showChat() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(14),dp(16),dp(14),dp(10)); root.setBackgroundColor(bg);
        TextView logo = label("J.A.R.V.I.S", 30, cyan); logo.setGravity(Gravity.CENTER); root.addView(logo);
        TextView sub = label("MOBILE AI  /  ONLINE", 12, Color.LTGRAY); sub.setGravity(Gravity.CENTER); root.addView(sub);
        status = label(prefs.getString("api_key", "").isEmpty() ? "API anahtarı gerekli" : "Hazır · Yapay zekâ bağlantısı için mesaj gönder", 12, Color.LTGRAY); root.addView(status);
        LinearLayout keyRow = new LinearLayout(this); keyRow.setOrientation(LinearLayout.HORIZONTAL);
        keyInput = new EditText(this); keyInput.setSingleLine(true); keyInput.setTextColor(white); keyInput.setHintTextColor(Color.GRAY); keyInput.setHint("OpenAI API anahtarı (sk-...)"); keyInput.setInputType(129); keyInput.setText(prefs.getString("api_key", ""));
        keyRow.addView(keyInput, new LinearLayout.LayoutParams(0,dp(52),1));
        Button save = button("Kaydet"); keyRow.addView(save); save.setOnClickListener(v -> { String k=keyInput.getText().toString().trim(); if(k.isEmpty()){Toast.makeText(this,"API anahtarını gir.",Toast.LENGTH_SHORT).show();return;} prefs.edit().putString("api_key",k).apply(); status.setText("API anahtarı cihazına kaydedildi"); hideKeyboard(keyInput); });
        root.addView(keyRow);
        scroll = new ScrollView(this); messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL); scroll.addView(messages); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        addMessage("JARVIS", "Bağımsız mobil arayüz hazır. İnternet ve kendi OpenAI API anahtarın gerekir. API kullanımı ayrıca ücretlendirilebilir.", false);
        LinearLayout compose = new LinearLayout(this); compose.setOrientation(LinearLayout.HORIZONTAL);
        input = new EditText(this); input.setTextColor(white); input.setHintTextColor(Color.GRAY); input.setHint("JARVIS'e mesaj yaz..."); input.setMinLines(1); input.setMaxLines(4);
        compose.addView(input,new LinearLayout.LayoutParams(0,dp(54),1));
        Button mic = button("🎙"); compose.addView(mic); mic.setOnClickListener(v -> startSpeech());
        Button send = button("Gönder"); compose.addView(send); send.setOnClickListener(v -> sendMessage());
        root.addView(compose); setContentView(root);
    }
    private void addMessage(String who, String msg, boolean user) {
        TextView t = label(who + "\n" + msg, 15, user ? white : cyan);
        t.setBackgroundColor(user ? Color.rgb(20,35,43) : Color.rgb(10,17,23)); t.setPadding(dp(12),dp(10),dp(12),dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(5),0,dp(5)); messages.addView(t,lp); scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }
    private void sendMessage() {
        String prompt = input.getText().toString().trim(); if(prompt.isEmpty()) return;
        String key = prefs.getString("api_key", ""); if(key.isEmpty()){Toast.makeText(this,"Önce API anahtarını Kaydet.",Toast.LENGTH_LONG).show();return;}
        input.setText(""); hideKeyboard(input); addMessage("SEN",prompt,true); status.setText("JARVIS düşünüyor...");
        try { history.put(new JSONObject().put("role","user").put("content",prompt)); } catch(Exception ignored) {}
        JSONArray requestHistory = new JSONArray();
        try { requestHistory.put(new JSONObject().put("role","system").put("content","Sen JARVIS adlı Türkçe konuşan, yardımcı ve güvenli bir mobil yapay zekâ asistanısın. Kısa ve açık yanıt ver.")); for(int i=Math.max(0,history.length()-16);i<history.length();i++) requestHistory.put(history.getJSONObject(i)); } catch(Exception ignored) {}
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL("https://api.openai.com/v1/chat/completions"); conn=(HttpURLConnection)url.openConnection(); conn.setRequestMethod("POST"); conn.setConnectTimeout(20000); conn.setReadTimeout(60000); conn.setDoOutput(true); conn.setRequestProperty("Authorization","Bearer "+key); conn.setRequestProperty("Content-Type","application/json");
                JSONObject body=new JSONObject(); body.put("model","gpt-4o-mini"); body.put("messages",requestHistory); body.put("temperature",0.7);
                try(OutputStream os=conn.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}
                int code=conn.getResponseCode(); InputStream stream=(code>=200&&code<300)?conn.getInputStream():conn.getErrorStream(); StringBuilder result=new StringBuilder();
                try(BufferedReader br=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8))){String line;while((line=br.readLine())!=null)result.append(line);}
                JSONObject json=new JSONObject(result.toString()); if(code<200||code>=300){String error=json.optJSONObject("error")!=null?json.getJSONObject("error").optString("message","API hatası"):"HTTP "+code; throw new Exception(error);}
                String answer=json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content"); history.put(new JSONObject().put("role","assistant").put("content",answer));
                runOnUiThread(() -> { addMessage("JARVIS",answer,false); status.setText("Çevrimiçi"); if(tts!=null) tts.speak(answer,TextToSpeech.QUEUE_FLUSH,null,"jarvis-answer"); });
            } catch(Exception e){String err=e.getMessage()==null?"Bağlantı hatası":e.getMessage(); runOnUiThread(() -> {addMessage("HATA",err,false);status.setText("Bağlantı başarısız");});}
            finally {if(conn!=null)conn.disconnect();}
        });
    }
    private void startSpeech() {
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"tr-TR"); i.putExtra(RecognizerIntent.EXTRA_PROMPT,"JARVIS'e konuş");
        try { startActivityForResult(i,SPEECH_REQUEST); } catch(Exception e){Toast.makeText(this,"Bu cihazda ses tanıma hizmeti bulunamadı.",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==SPEECH_REQUEST&&resultCode==RESULT_OK&&data!=null){ArrayList<String> r=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(r!=null&&!r.isEmpty()){input.setText(r.get(0));sendMessage();}}}
    private void hideKeyboard(View v){((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(),0);}
    @Override protected void onDestroy(){super.onDestroy();executor.shutdownNow();if(tts!=null){tts.stop();tts.shutdown();}}
}
