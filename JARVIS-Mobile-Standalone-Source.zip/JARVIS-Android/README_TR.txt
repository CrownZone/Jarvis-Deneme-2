JARVIS Mobile - bağımsız Android istemcisi

Özellikler:
- Telefonda sohbet arayüzü
- OpenAI API ile yanıt üretme (internet gerekir; API ayrıca ücretlidir)
- Android ses tanıma ve metin okuma
- API anahtarı cihazın uygulama tercihleri içinde saklanır

Güvenlik notu:
Bu sürüm kişisel kullanım için doğrudan OpenAI API'sine bağlanır. APK içindeki anahtar profesyonel/kurumsal dağıtım için güvenli bir yöntem değildir; cihazı kullanan biri uygulamanın yerel verilerine erişebilir. API anahtarını kimseyle paylaşmayın ve kullanım limitleri belirleyin. Daha güvenli dağıtım için sunucu taraflı proxy gerekir.

APK derleme:
GitHub Actions iş akışı .github/workflows/build-apk.yml içinde bulunur. Projeyi GitHub deposuna yükleyip Actions > Build JARVIS Android APK > Run workflow ile çalıştırın. Oluşan APK Artifacts bölümündedir.
